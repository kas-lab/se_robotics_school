#!/bin/bash
set -e

command -v fixuid > /dev/null 2>&1 || { echo 'ERROR: fixuid not found in container image. Please rebuild the image.' >&2; exit 1; }; eval $(fixuid -q)

SCENARIO_EXECUTION_PARAMETERS="${SCENARIO_EXECUTION_PARAMETERS:-}"

# Setup
# OUTPUT_DIR holds this job's job-level artifacts (sysinfo, resource monitor,
# logs, rosbag). SCENARIO_OUTPUT_DIR is scenario_execution's -o; per-config
# results land under it via each parameter document's _output_dir.
# In single-config jobs both default to /out (the run directory). In packed
# multi-config jobs /out is the campaign root, so the launcher points OUTPUT_DIR
# at a per-unit subdir (avoiding cross-unit collisions) while SCENARIO_OUTPUT_DIR
# stays /out so per-config results are written to /out/<config>/<run>.
OUTPUT_DIR="${OUTPUT_DIR:-/out}"
SCENARIO_OUTPUT_DIR="${SCENARIO_OUTPUT_DIR:-${OUTPUT_DIR}}"
LOG_DIR="${OUTPUT_DIR}/logs"
mkdir -p "${LOG_DIR}"

# Determine log filename
LOG_FILE="${LOG_DIR}/system.log"

# Function to log to both console and file
log() {
    echo "$@" | tee -a "${LOG_FILE}"
}

log "Running as UID: $(id -u), GID: $(id -g)..."

# Collect system information (non-fatal)
log "Collecting system information..."
INSTANCE_TYPE=""
SYSINFO_FILE="${OUTPUT_DIR}/sysinfo.yaml"
python3 /config/collect_sysinfo.py --output "${SYSINFO_FILE}" --external "instance_type=${INSTANCE_TYPE}" --external "available_cpus=${AVAILABLE_CPUS}" --external "available_mem=${AVAILABLE_MEM}"

# setup ros2 environment (optional — skipped when ROS is not present)
if [ -n "$ROS_DISTRO" ] && [ -f "/opt/ros/$ROS_DISTRO/setup.bash" ]; then
    log "Setting up ROS2 environment..."
    source "/opt/ros/$ROS_DISTRO/setup.bash" --
    if [ -f "/ws/install/setup.bash" ]; then
        source "/ws/install/setup.bash" --
    fi
fi

# Check if X11 is enabled (default: true for backward compatibility)
if [ "${ENABLE_X11}" != "false" ]; then
  log "Starting X11 virtual display..."
  if [ -z "${DISPLAY}" ]; then
    export DISPLAY=:0
  fi

  if [ -S "/tmp/.X11-unix/X${DISPLAY/:/}" ]; then
    echo "x11 already running..."
  else

    mkdir -p /tmp/runtime-user 2>/dev/null || true
    mkdir -p /tmp/.X11-unix 2>/dev/null || true
    chmod 1777 /tmp/.X11-unix 2>/dev/null || true
    ln -snf /dev/ptmx /dev/tty7 2>/dev/null || true

    Xvfb tty7 -noreset -dpi "${DPI}" +extension "RANDR" +extension "RENDER" +extension "MIT-SHM" -screen ${DISPLAY} ${SIZEW}x${SIZEH}x${CDEPTH} "${DISPLAY}" 2>/dev/null &

    echo -n "Waiting for X socket..."
    until [ -S "/tmp/.X11-unix/X${DISPLAY/:/}" ]; do sleep 1; done
    echo "DONE"

    if [ -n "${NOVNC_ENABLE}" ]; then
      echo "Starting VNC..."
      x11vnc -display "${DISPLAY}" -shared -forever -repeat -xkb -snapfb -threads -xrandr "resize" -rfbport 5900 -bg
      /opt/noVNC/utils/novnc_proxy --vnc localhost:5900 --listen 8080 --heartbeat 10 &
    fi

    if [ -n "${WINDOW_MANAGER_ENABLE}" ]; then
      echo "Starting Window Manager..."
      openbox &
    fi
  fi
else
  log "X11 disabled - skipping virtual display setup"
fi

# Only redirect output to log file if not running an interactive shell
if [ "$#" -eq 0 ] || [[ "$@" != *"bash"* && "$@" != *"sh"* ]]; then
    # Run the actual command and capture output
    # Using unbuffered tee for real-time output
    exec > >(stdbuf -oL tee -a "${LOG_FILE}")
    exec 2>&1
fi

log "Entrypoint script initialized"

if [ "$#" -ne 0 ]; then
    log "Executing custom command: $@"
    exec "$@"
else
    # Validate PRE_COMMAND exists if specified
    if [ -n "${PRE_COMMAND}" ]; then
        if [ -e "${PRE_COMMAND}" ]; then
            log "Executing pre-command: ${PRE_COMMAND}"
            source "${PRE_COMMAND}"
        else
            log "ERROR: Pre-command '${PRE_COMMAND}' does not exist."
            exit 1
        fi
    fi

    # Start built-in daemons
    start-stop-daemon --start --background --make-pidfile --pidfile /tmp/monitor.pid \
        --startas /usr/bin/python3 -- /config/monitor_resources.py "${OUTPUT_DIR}/resource_usage_main.csv"
    log "Started resource monitor (PID=$(cat /tmp/monitor.pid)) -> ${OUTPUT_DIR}/resource_usage_main.csv"

    if command -v ros2 > /dev/null 2>&1; then
        start-stop-daemon --start --background --make-pidfile --pidfile /tmp/rosbag.pid \
            --startas /bin/bash -- -c "exec ros2 bag record -o ${OUTPUT_DIR}/logs/rosout_bag --storage mcap --topics /rosout"
        log "Started rosbag recording /rosout (PID=$(cat /tmp/rosbag.pid)) -> ${OUTPUT_DIR}/logs/rosout_bag"
    fi

    # Build built-in cleanup script (stop rosbag and resource monitor gracefully)
    BUILTIN_CLEANUP_SCRIPT="/tmp/robovast_cleanup.sh"
    cat > "${BUILTIN_CLEANUP_SCRIPT}" << 'CLEANUP_EOF'
#!/bin/bash
if [ -f /tmp/rosbag.pid ]; then
    if start-stop-daemon --stop --signal INT --pidfile /tmp/rosbag.pid >/dev/null 2>&1; then
        _t=0
        while kill -0 $(cat /tmp/rosbag.pid) 2>/dev/null && [ $_t -lt 50 ]; do
            sleep 0.1; _t=$((_t + 1))
        done
        kill -KILL $(cat /tmp/rosbag.pid) 2>/dev/null || true
    fi
    echo "ROS bag process stopped."
fi
if [ -f /tmp/monitor.pid ]; then
    if kill -TERM $(cat /tmp/monitor.pid) 2>/dev/null; then
        _t=0
        while kill -0 $(cat /tmp/monitor.pid) 2>/dev/null && [ $_t -lt 30 ]; do
            sleep 0.1; _t=$((_t + 1))
        done
        kill -KILL $(cat /tmp/monitor.pid) 2>/dev/null || true
    fi
    echo "Resource monitor process stopped."
fi
exit 0
CLEANUP_EOF
    chmod +x "${BUILTIN_CLEANUP_SCRIPT}"

    POST_COMMAND_PARAM="--post-run ${BUILTIN_CLEANUP_SCRIPT}"
    if [ -n "${POST_COMMAND}" ]; then
        if [ -e "${POST_COMMAND}" ]; then
            POST_COMMAND_PARAM="--post-run ${POST_COMMAND} --post-run ${BUILTIN_CLEANUP_SCRIPT}"
            log "Post-command '${POST_COMMAND}' will run before built-in cleanup."
        else
            log "ERROR: Post-command '${POST_COMMAND}' does not exist."
            exit 1
        fi
    fi

    SCENARIO_FILE="${SCENARIO_FILE:-scenario.osc}"
    # Parameter file is a single-config scenario.config by default. In
    # multi-config-per-job mode robovast supplies a multi-document parameter
    # file (one document per packed configuration) and sets
    # OUTPUT_RESULT_PER_SCENARIO=true so scenario_execution writes a separate
    # test.xml into each configuration's _output_dir subdirectory.
    SCENARIO_PARAMETER_FILE="${SCENARIO_PARAMETER_FILE:-/config/scenario.config}"
    PER_SCENARIO_PARAM=""
    if [ "${OUTPUT_RESULT_PER_SCENARIO}" = "true" ]; then
        PER_SCENARIO_PARAM="--output-result-per-scenario"
    fi
    if command -v ros2 > /dev/null 2>&1; then
        if [ -e "${SCENARIO_PARAMETER_FILE}" ]; then
            log "Starting scenario execution (ROS2) with config file..."
            log "Commandline: ros2 run scenario_execution_ros scenario_execution_ros -o ${SCENARIO_OUTPUT_DIR} /config/${SCENARIO_FILE} ${POST_COMMAND_PARAM} --scenario-parameter-file ${SCENARIO_PARAMETER_FILE} ${PER_SCENARIO_PARAM} ${SCENARIO_EXECUTION_PARAMETERS}"
            exec ros2 run scenario_execution_ros scenario_execution_ros -o ${SCENARIO_OUTPUT_DIR} /config/${SCENARIO_FILE} ${POST_COMMAND_PARAM} --scenario-parameter-file ${SCENARIO_PARAMETER_FILE} ${PER_SCENARIO_PARAM} ${SCENARIO_EXECUTION_PARAMETERS}
        else
            log "Starting scenario execution (ROS2) without config file..."
            exec ros2 run scenario_execution_ros scenario_execution_ros -o ${SCENARIO_OUTPUT_DIR} /config/${SCENARIO_FILE} ${POST_COMMAND_PARAM} ${SCENARIO_EXECUTION_PARAMETERS}
        fi
    else
        if [ -e "${SCENARIO_PARAMETER_FILE}" ]; then
            log "Starting scenario execution with config file..."
            log "Commandline: scenario_execution -o ${SCENARIO_OUTPUT_DIR} /config/${SCENARIO_FILE} ${POST_COMMAND_PARAM} --scenario-parameter-file ${SCENARIO_PARAMETER_FILE} ${PER_SCENARIO_PARAM} ${SCENARIO_EXECUTION_PARAMETERS}"
            exec scenario_execution -o ${SCENARIO_OUTPUT_DIR} /config/${SCENARIO_FILE} ${POST_COMMAND_PARAM} --scenario-parameter-file ${SCENARIO_PARAMETER_FILE} ${PER_SCENARIO_PARAM} ${SCENARIO_EXECUTION_PARAMETERS}
        else
            log "Starting scenario execution without config file..."
            exec scenario_execution -o ${SCENARIO_OUTPUT_DIR} /config/${SCENARIO_FILE} ${POST_COMMAND_PARAM} ${SCENARIO_EXECUTION_PARAMETERS}
        fi
    fi
fi
